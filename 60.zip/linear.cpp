#include<iostream>
#include <fstream>
#include <sstream>
#include <string>
#include<bits/stdc++.h>
#include<cmath>

using namespace std;

void printMatrix(const vector<vector<double>>& vec) {
    // Iterate over the outer vector (rows)
    for (const auto& row : vec) {
        // Iterate over each element in the row
        for (const auto& element : row) {
            cout << element << " ";
        }
        cout << endl; // Move to the next line after printing each row
    }
}

vector <vector <double>> calculate_coefficients(){
    ifstream file("train.csv");
    vector <vector <double>> matrix;
    string line;

    getline(file,line); //header

    string date;
    string closep;
    string openp;
    string vwapp;
    string lowp;
    string highp;
    string tradesp;
    string open;

    double closepv;
    double openpv;
    double vwappv;
    double lowpv;
    double highpv;
    double tradespv;
    double openv;

    getline(file,line); //first value
    istringstream oneline(line);

    getline(oneline, date,',');
    getline(oneline, closep,',');
    getline(oneline, openp,',');
    getline(oneline, vwapp,',');
    getline(oneline, lowp,',');
    getline(oneline, highp,',');
    getline(oneline, tradesp,'\n');

    closepv = stod(closep);
    openpv = stod(openp);
    vwappv = stod(vwapp);
    lowpv = stod(lowp);
    highpv = stod(highp);
    tradespv = stod(tradesp);

    while(getline(file,line)){
        istringstream oneline(line);

        getline(oneline, date,',');
        getline(oneline, closep,',');
        getline(oneline, openp,',');
        getline(oneline, vwapp,',');
        getline(oneline, lowp,',');
        getline(oneline, highp,',');
        getline(oneline, tradesp,'\n');

        openv = stod(openp);

        vector<double> temp = {closepv,openpv,vwappv,lowpv,highpv,tradespv,openv};
        matrix.push_back(temp);

        closepv = stod(closep);
        openpv = stod(openp);
        vwappv = stod(vwapp);
        lowpv = stod(lowp);
        highpv = stod(highp);
        tradespv = stod(tradesp);

    }

    return matrix;
}

vector <vector <double>> transpose_matrix(vector <vector <double>> &matrix){
    
    if(matrix.empty() or matrix[0].empty()){
        return {};
    }
    int rows = matrix.size();
    int cols = matrix[0].size();

    vector<vector<double>> transpose(cols, vector<double>(rows));

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            transpose[j][i] = matrix[i][j];
        }
    }

    return transpose;

}

vector <vector <double>> multiply_matrix(vector <vector <double>> &m1, vector <vector <double>> &m2){
    if (m1.empty() || m1[0].empty() || m2.empty() || m2[0].empty()) {
        return {}; 
    }

    if (m1[0].size() != m2.size()) {
        cout << "these matrices cannot be multiplied!" << endl;
        return {};
    }

    
    int rows1 = m1.size();
    int cols1 = m1[0].size();
    int cols2 = m2[0].size();

    vector<vector<double>> result(rows1, vector<double>(cols2, 0.0));

    for (int i = 0; i < rows1; ++i) {
        for (int j = 0; j < cols2; ++j) {
            for (int k = 0; k < cols1; ++k) {
                result[i][j] += m1[i][k] * m2[k][j];
            }
        }
    }

    return result;
}

double determinant(vector<vector<double>>& matrix) {
    int n = matrix.size();
    
    if (n == 1) {
        return matrix[0][0];
    }
    
    double det = 0;
    vector<vector<double>> submatrix(n-1, vector<double>(n-1));
    
    
    for (int i = 0; i < n; ++i) {
        for (int row = 1; row < n; ++row) {
            int col_index = 0;
            for (int col = 0; col < n; ++col) {
                if (col != i) {
                    submatrix[row-1][col_index++] = matrix[row][col];
                }
            }
        }
        
        double sign = (i % 2 == 0) ? 1 : -1; 
        det += sign * matrix[0][i] * determinant(submatrix);
    }
    
    return det;
}

int cofactor(vector<vector<double>>& matrix, int row, int col, int n) {
  
  double subN = n - 1;

  vector<vector<double>> subMatrix(subN, vector<double>(subN));
  int i1 = 0, j1 = 0;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      if (i != row && j != col) {
        subMatrix[i1][j1] = matrix[i][j];
        j1++;
        if (j1 == subN) {
          j1 = 0;
          i1++;
        }
      }
    }
  }

  double det = determinant(subMatrix);

  int sign = ((row + col) % 2 == 0) ? 1 : -1;

  return sign * det;
}

vector<vector<double>> adjoint(vector<vector<double>>& matrix, int n) {
  
  if (n != matrix.size() || n != matrix[0].size()) {
    cout << "Matrix must be square." << endl;
  }

  vector<vector<double>> adj(n, vector<double>(n));

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      adj[j][i] = cofactor(matrix, i, j, n);
    }
  }

  return adj;
}

vector<vector<double>> inverse(vector<vector<double>>& matrix, int n) {
    if (n != matrix.size() || n != matrix[0].size()) {
        cout << "Matrix must be square." << endl;  
    }

  double det = determinant(matrix);
  if (det == 0.0) {
    cout << "Determinant must be non-zero" << endl;  
  }

  vector<vector<double>> adj = adjoint(matrix, n);
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      adj[i][j] /= det;
    }
  }
  return adj;
}

int main(int argc, char *argv[]){

  // vector <vector <double>> m = calculate_coefficients();
  // vector <vector <double>> t = transpose_matrix(m);

  // printMatrix(m);
  // cout << "ok" << endl;
  // printMatrix(t);
  // cout << "ok" << endl;
  // vector <vector <double>> mul = multiply_matrix(m,t);
  // printMatrix(mul);

  

  vector<vector<double>> m = {{2,1,6},{1,6,5},{8,5,2}};
  int n = m.size();

  vector <vector <double>> i = inverse(m,n);
  printMatrix(i);

  // cout << "ok1" << endl;

  return 0;
}